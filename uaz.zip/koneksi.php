<?php 
$host = "localhost";
$username = "id14362046_kire";
$pass = "pb%zRc%e0$]3ypaq";
$database = "id14362046_klompok9";

$db = mysqli_connect("$host","$username","$pass","$database");

?>